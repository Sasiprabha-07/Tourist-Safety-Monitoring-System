package com.example.tourist_safety;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TouristSafetyMonitoringSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TouristSafetyMonitoringSystemApplication.class, args);
	}

}
