package com.example.tourist_safety;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TouristSafetyMonitoringSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
